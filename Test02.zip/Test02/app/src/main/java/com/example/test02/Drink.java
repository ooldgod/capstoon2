package com.example.test02;

public class Drink {
    private int id; // id 필드 추가
    private String name;
    private int price;
    private String convenienceStore;
    private boolean hasEvent;
    private String event;
    private String category;
    private String updateDate;
    private Integer likeCount;
    private Integer dislikeCount;

    public Drink(String name, int price, String convenienceStore, boolean hasEvent, String event, String category, String updateDate) {
        this.name = name;
        this.price = price;
        this.convenienceStore = convenienceStore;
        this.hasEvent = hasEvent;
        this.event = event;
        this.category = category;
        this.updateDate = updateDate;
        this.likeCount = 0;
        this.dislikeCount = 0;
    }

    // Getter 및 Setter 메서드 추가
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public String getConvenienceStore() {
        return convenienceStore;
    }

    public boolean hasEvent() {
        return hasEvent;
    }

    public String getEvent() {
        return event;
    }

    public String getCategory() {
        return category;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public Integer getDislikeCount() {
        return dislikeCount;
    }

    public void like() {
        if (likeCount == null) {
            likeCount = 1;
        } else {
            likeCount++;
        }
    }

    public void dislike() {
        if (dislikeCount == null) {
            dislikeCount = 1;
        } else {
            dislikeCount++;
        }
    }

    public void cancelLike() {
        if (likeCount != null && likeCount > 0) {
            likeCount--;
        }
    }

    public void cancelDislike() {
        if (dislikeCount != null && dislikeCount > 0) {
            dislikeCount--;
        }
    }
}
