package com.example.test02;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import android.widget.Button;
import androidx.fragment.app.FragmentTransaction;

public class MyInfoActivity extends AppCompatActivity {

    private static final String TAG = "MyInfoActivity";
    private TextView tvName, tvNickname, tvBirthdate, tvPhone, tvEmail, tvUserNameInfo;
    private ImageView ivUserProfile;
    private TextView tvEdit;
    private Button btnLogout;

    // Firestore 및 인증 인스턴스 생성
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    private LoginActivity fragmentMore;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_info);

        // Firestore 및 인증 초기화
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // 레이아웃 요소 연결
        tvName = findViewById(R.id.tvName);
        tvNickname = findViewById(R.id.tvNickname);
        tvBirthdate = findViewById(R.id.tvBirthdate);
        tvPhone = findViewById(R.id.tvPhone);
        tvEmail = findViewById(R.id.tvEmail);
        ivUserProfile = findViewById(R.id.ivUserProfile);
        tvUserNameInfo = findViewById(R.id.tvUserNameInfo);
        tvEdit = findViewById(R.id.tvEdit);
        btnLogout = findViewById(R.id.btnLogout);

        fragmentMore = new LoginActivity();

        // 수정 버튼 클릭 이벤트 설정
        tvEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 수정 화면으로 이동
                Intent intent = new Intent(MyInfoActivity.this, MyEditActivity.class);
                startActivity(intent);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frame_layout, fragmentMore).commitAllowingStateLoss();;
                transaction.addToBackStack(null);  // 뒤로 가기 버튼을 눌렀을 때 이전 프래그먼트로 돌아갈 수 있도록 함
                transaction.commit();
            }
        });

        // 사용자 정보 가져오기
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String email = currentUser.getEmail();
            getUserInfoFromFirestore(email);
        } else {
            Log.d(TAG, "No user signed in");
        }
    }

    private void getUserInfoFromFirestore(String email) {
        // Firestore의 "users" 컬렉션에서 해당 이메일로 문서를 조회하여 사용자 정보 가져오기
        db.collection("users")
                .whereEqualTo("email", email)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (DocumentSnapshot document : task.getResult()) {
                            // 문서가 존재하는 경우 사용자 정보 가져오기
                            String name = document.getString("name");
                            String nickname = document.getString("nickname");
                            String birthdate = document.getString("birthdate");
                            String phone = document.getString("phone");
                            String userEmail = document.getString("email");

                            // 사용자의 닉네임을 가져와서 표시
                            String userNameInfo = nickname + "의 정보";
                            tvUserNameInfo.setText(userNameInfo);

                            // 가져온 정보를 TextView에 설정
                            tvName.setText(name);
                            tvNickname.setText(nickname);
                            tvBirthdate.setText(birthdate);
                            tvPhone.setText(phone);
                            tvEmail.setText(userEmail);
                        }
                    } else {
                        Log.d(TAG, "Error getting documents: ", task.getException());
                    }
                });
    }
}