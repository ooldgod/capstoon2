package com.example.test02;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;
import android.content.Intent;

import androidx.annotation.NonNull;
import android.app.Activity;
import android.widget.ToggleButton;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.CompoundButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

public class DrinkAdapter extends RecyclerView.Adapter<DrinkAdapter.ViewHolder> {

    private List<Drink> drinks;
    private List<Drink> filteredDrinks;
    private Activity activity;

    public DrinkAdapter(Activity activity, List<Drink> drinks) {
        this.activity = activity;
        this.drinks = drinks;
        this.filteredDrinks = new ArrayList<>(drinks); // 이 부분을 수정하여 새로운 빈 리스트로 초기화합니다.
    }
    public void setFilteredDrinks(List<Drink> filteredDrinks) {
        this.filteredDrinks = filteredDrinks;
        notifyDataSetChanged(); // 데이터가 변경되었음을 알립니다.
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_drink, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Drink currentDrink = filteredDrinks.get(position);
        ImageView productImageView = holder.productImageView;
        holder.productImageView.setBackgroundColor(Color.WHITE);

        // Glide를 사용하여 이미지 로드
        Glide.with(holder.productImageView.getContext())
                .load(currentDrink.getImageUrl())
                .into(holder.productImageView);


        holder.nameTextView.setText(currentDrink.getName());
        holder.priceTextView.setText(String.valueOf(currentDrink.getPrice()));
        holder.convenienceStoreTextView.setText(currentDrink.getConvenienceStore());
        holder.eventTextView.setText(currentDrink.hasEvent() ? currentDrink.getEvent() : "이벤트 없음");
        holder.categoryTextView.setText(currentDrink.getCategory());
        holder.updateDateTextView.setText(currentDrink.getUpdateDate());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Drink clickedItem = filteredDrinks.get(position);
                    // 클릭된 상품의 자세한 정보를 보여주는 액티비티로 이동
                    Intent intent = new Intent(activity, DetailedInfoActivity.class);
                    intent.putExtra("drink_id", clickedItem.getId());
                    activity.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return filteredDrinks.size();
    }

    public void filter(String selectedCategory, String selectedSortType) {
        // 필터링된 음료를 저장할 리스트
        ArrayList<Drink> filteredDrinks = new ArrayList<>();

        // 선택된 카테고리에 따라 음료를 필터링
        if (selectedCategory.equals("전체")) {
            filteredDrinks.addAll(drinks); // "전체" 선택 시 모든 상품 추가
        } else {
            for (Drink drink : drinks) {
                if (drink.getCategory().equals(selectedCategory)) {
                    filteredDrinks.add(drink);
                }
            }
        }

        // 선택된 정렬 방식에 따라 음료를 정렬
        switch (selectedSortType) {
            case "가격 낮은 순":
                Collections.sort(filteredDrinks, new Comparator<Drink>() {
                    @Override
                    public int compare(Drink drink1, Drink drink2) {
                        return drink1.getPrice() - drink2.getPrice();
                    }
                });
                break;
            case "가격 높은 순":
                Collections.sort(filteredDrinks, new Comparator<Drink>() {
                    @Override
                    public int compare(Drink drink1, Drink drink2) {
                        return drink2.getPrice() - drink1.getPrice();
                    }
                });
                break;
            case "최신 상품 순":
                Collections.sort(filteredDrinks, new Comparator<Drink>() {
                    @Override
                    public int compare(Drink drink1, Drink drink2) {
                        // 날짜를 비교하여 내림차순으로 정렬합니다.
                        return drink2.getUpdateDate().compareTo(drink1.getUpdateDate());
                    }
                });
                break;
            case "인기 상품 순":
                Collections.sort(filteredDrinks, new Comparator<Drink>() {
                    @Override
                    public int compare(Drink drink1, Drink drink2) {
                        // 추천 횟수로 내림차순 정렬합니다.
                        return Integer.compare(drink2.getLikeCount(), drink1.getLikeCount());
                    }
                });
                break;
            // 추가적으로 필요한 정렬 조건을 여기에 추가할 수 있습니다.
            default:
                // 기본적으로는 가격 낮은 순으로 정렬합니다.
                Collections.sort(filteredDrinks, new Comparator<Drink>() {
                    @Override
                    public int compare(Drink drink1, Drink drink2) {
                        return drink1.getPrice() - drink2.getPrice();
                    }
                });
                break;
        }

        // 필터링 및 정렬된 음료 리스트를 어댑터에 설정하고 변경 사항을 알립니다.
        setFilteredDrinks(filteredDrinks);
        notifyDataSetChanged();
    }
    public void filterByStore(String selectedStore) {
        // 선택된 편의점에 해당하는 상품만 필터링
        ArrayList<Drink> filteredDrinks = new ArrayList<>();
        for (Drink drink : drinks) {
            if (selectedStore.equals("전체") || drink.getConvenienceStore().equals(selectedStore)) {
                filteredDrinks.add(drink);
            }
        }
        // 필터링된 음료 리스트를 어댑터에 설정하고 변경 사항을 알림
        setFilteredDrinks(filteredDrinks);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {
        public ImageView productImageView;

        public TextView nameTextView;
        public TextView priceTextView;
        public TextView convenienceStoreTextView;
        public TextView eventTextView;
        public TextView categoryTextView;
        public TextView updateDateTextView;
        public ToggleButton likeToggleButton;
        public TextView likeCountTextView;
        public ToggleButton dislikeToggleButton;
        public TextView dislikeCountTextView;

        public ViewHolder(View itemView) {
            super(itemView);

            productImageView = itemView.findViewById(R.id.productImageView); // 이미지 뷰 초기화
            nameTextView = itemView.findViewById(R.id.nameTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            convenienceStoreTextView = itemView.findViewById(R.id.convenienceStoreTextView);
            eventTextView = itemView.findViewById(R.id.eventTextView);
            categoryTextView = itemView.findViewById(R.id.categoryTextView);
            updateDateTextView = itemView.findViewById(R.id.updateDateTextView);
            likeToggleButton = itemView.findViewById(R.id.likeToggleButton);
            likeCountTextView = itemView.findViewById(R.id.likeCountTextView);
            dislikeToggleButton = itemView.findViewById(R.id.dislikeToggleButton);
            dislikeCountTextView = itemView.findViewById(R.id.dislikeCountTextView);


            likeToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Drink clickedItem = filteredDrinks.get(position);
                        if (isChecked) {
                            clickedItem.like(); // 추천 카운터를 증가시킵니다.
                        } else {
                            clickedItem.cancelLike(); // 추천 카운터를 감소시킵니다.
                        }
                        likeCountTextView.setText(String.valueOf(clickedItem.getLikeCount())); // 추천 카운터를 업데이트합니다.
                    }
                }
            });

            // 비추천 토글 버튼 클릭 시
            dislikeToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        Drink clickedItem = filteredDrinks.get(position);
                        if (isChecked) {
                            clickedItem.dislike(); // 비추천 카운터를 증가시킵니다.
                        } else {
                            clickedItem.cancelDislike(); // 비추천 카운터를 감소시킵니다.
                        }
                        dislikeCountTextView.setText(String.valueOf(clickedItem.getDislikeCount())); // 비추천 카운터를 업데이트합니다.
                    }
                }
            });



        }
    }
}
