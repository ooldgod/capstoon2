package com.example.test02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import com.google.android.material.tabs.TabLayout;

import android.widget.Spinner;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;



import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DrinkAdapter adapter;
    private List<Drink> drinks;
    private EditText searchEditText;
    private ImageButton filterImageButton;

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // 1. 데이터 준비
        drinks = new ArrayList<>();
        drinks.add(new Drink("콜라", 1000, "이마트", false, null, "음료", "2024-02-21"));
        drinks.add(new Drink("사이다", 1500, "CU", true, "할인", "음료", "2024-02-23"));
        drinks.add(new Drink("주스", 2000, "GS25", false, null, "음료", "2024-02-24"));
        drinks.add(new Drink("라면", 3000, "세븐일레븐", true, "1+1", "식품", "2024-02-25"));
        drinks.add(new Drink("김밥", 2500, "미니스탑", false, null, "식품", "2024-02-29"));


        // 2. RecyclerView 설정
        recyclerView = findViewById(R.id.recyclerView);
        adapter = new DrinkAdapter(this, drinks);
        adapter.filter("전체","가격 낮은 순");
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // 3. 편의점 버튼 클릭 이벤트 처리
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Tab이 선택되었을 때 해당하는 편의점 상품 목록 표시
                int position = tab.getPosition();
                switch (position) {
                    case 0:
                        // 전체 상품 목록 표시
                        Toast.makeText(MainActivity.this, "전체", Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        // GS25 상품 목록 표시
                        Toast.makeText(MainActivity.this, "GS25", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        // 세븐일레븐 상품 목록 표시
                        Toast.makeText(MainActivity.this, "세븐일레븐", Toast.LENGTH_SHORT).show();
                        break;
                    case 3:
                        // CU 상품 목록 표시
                        Toast.makeText(MainActivity.this, "CU", Toast.LENGTH_SHORT).show();
                        break;
                    case 4:
                        // 미니스톱 상품 목록 표시
                        Toast.makeText(MainActivity.this, "미니스톱", Toast.LENGTH_SHORT).show();
                        break;
                    case 5:
                        // 이마트24 상품 목록 표시
                        Toast.makeText(MainActivity.this, "이마트24", Toast.LENGTH_SHORT).show();
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Do nothing
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Do nothing
            }
        });

        Spinner firstSpinner = findViewById(R.id.firstSpinner);
        Spinner secondSpinner = findViewById(R.id.secondSpinner);
        firstSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = (String) parent.getItemAtPosition(position);
                String selectedSortType = (String) secondSpinner.getSelectedItem(); // 두 번째 스피너에서 선택된 정렬 방식 가져오기
                adapter.filter(selectedCategory, selectedSortType); // 정렬 방식을 함께 전달하여 필터링 및 정렬 수행
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
        secondSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedSortType = (String) parent.getItemAtPosition(position);
                String selectedCategory = (String) firstSpinner.getSelectedItem(); // 첫 번째 스피너에서 선택된 카테고리 가져오기
                adapter.filter(selectedCategory, selectedSortType); // 카테고리와 정렬 방식을 함께 전달하여 필터링 및 정렬 수행
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 아무것도 선택되지 않았을 때 처리
            }
        });

    }

}