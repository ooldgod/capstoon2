package com.example.test02;


import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import com.google.android.material.tabs.TabLayout;

import android.view.ViewGroup;
import android.widget.Spinner;
import android.widget.AdapterView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


import android.util.Log;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class MainActivity extends Fragment {

    private RecyclerView recyclerView;
    private DrinkAdapter adapter;
    private List<Drink> drinks;

    private static final String TAG = "MainActivity";
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MainActivity() {
        // Required empty public constructor
    }


    public static MainActivity newInstance(String param1, String param2) {
        MainActivity fragment = new MainActivity();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.activity_main, container, false);
        recyclerView = (RecyclerView) rootView.findViewById(R.id.recyclerView);
        drinks = new ArrayList<>();
        // Firestore 인스턴스 가져오기
        recyclerView = rootView.findViewById(R.id.recyclerView);
        adapter = new DrinkAdapter(getActivity(), drinks);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String collectionPath = "2024_01편의점상품";

// Firestore에서 해당 컬렉션의 문서를 가져오기
        db.collection(collectionPath)
                .limit(10)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        int count = 0;
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Firestore에서 가져온 데이터로 Drink 객체 생성 및 리스트에 추가
                            boolean hasEvent = false;
                            String event = null;
                            Object eventProduct = document.get("event_product");
                            if (eventProduct != null) {
                                if (eventProduct instanceof String) {
                                    String eventString = (String) eventProduct;
                                    if (!eventString.equals("NaN")) {
                                        hasEvent = true;
                                        event = eventString;
                                    }
                                } else {
                                    // If it's not a string, consider it as having an event
                                    hasEvent = true;
                                }
                            }

                            String originalUrl = document.getString("image_url");
                            String secureUrl = originalUrl.replace("http://", "https://");

                            Drink drink = new Drink(
                                    document.getString("product_name"),  // 상품명
                                    document.getDouble("price").intValue(), // 가격
                                    document.getString("store"), // 편의점
                                    hasEvent, // 이벤트 여부
                                    event, // 이벤트 정보
                                    document.getString("main_category"), // 메인 카테고리
                                    "2024-01", // 업데이트 날짜
                                    secureUrl
                            );
                            drinks.add(drink);
                        }
                        // 어댑터에 데이터 변경 알림
                        adapter.notifyDataSetChanged();
                    } else {
                        Log.w(TAG, "Error getting documents.", task.getException());
                    }
                    adapter.filter("전체", "가격 낮은 순");
                });

        // 3. 편의점 버튼 클릭 이벤트 처리
        TabLayout tabLayout = rootView.findViewById(R.id.tabLayout);
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Tab이 선택되었을 때 해당하는 편의점 상품 목록 표시
                int position = tab.getPosition();
                String selectedStore = "";
                switch (position) {
                    case 0:
                        // 전체 상품 목록 표시
                        Toast.makeText(getActivity(), "전체", Toast.LENGTH_SHORT).show();
                        selectedStore = "전체";
                        break;
                    case 1:
                        // GS25 상품 목록 표시
                        Toast.makeText(getActivity(), "7-ELEVEn", Toast.LENGTH_SHORT).show();
                        selectedStore = "7-ELEVEn";
                        break;
                    case 2:
                        // 세븐일레븐 상품 목록 표시
                        Toast.makeText(getActivity(), "GS25", Toast.LENGTH_SHORT).show();
                        selectedStore = "GS25";
                        break;
                    case 3:
                        // CU 상품 목록 표시
                        Toast.makeText(getActivity(), "CU", Toast.LENGTH_SHORT).show();
                        selectedStore = "CU";
                        break;
                    case 4:
                        // 미니스톱 상품 목록 표시
                        Toast.makeText(getActivity(), "Emart24", Toast.LENGTH_SHORT).show();
                        selectedStore = "Emart24";
                        break;
                }
                adapter.filterByStore(selectedStore);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Do nothing
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Do nothing
            }
        });

        Spinner firstSpinner = rootView.findViewById(R.id.firstSpinner);
        Spinner secondSpinner = rootView.findViewById(R.id.secondSpinner);
        firstSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = (String) parent.getItemAtPosition(position);
                String selectedSortType = (String) secondSpinner.getSelectedItem(); // 두 번째 스피너에서 선택된 정렬 방식 가져오기
                adapter.filter(selectedCategory, selectedSortType); // 정렬 방식을 함께 전달하여 필터링 및 정렬 수행
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
        secondSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedSortType = (String) parent.getItemAtPosition(position);
                String selectedCategory = (String) firstSpinner.getSelectedItem(); // 첫 번째 스피너에서 선택된 카테고리 가져오기
                adapter.filter(selectedCategory, selectedSortType); // 카테고리와 정렬 방식을 함께 전달하여 필터링 및 정렬 수행
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 아무것도 선택되지 않았을 때 처리
            }
        });
        return rootView;
    }
}