package com.example.test02;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MyEditActivity extends AppCompatActivity {

    private EditText nameEditText, nicknameEditText, birthdateEditText, phoneEditText, emailEditText, passwordEditText;
    private Button editButton, backButton;

    // Firebase
    private DatabaseReference usersRef;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_edit);

        // Firebase 초기화
        usersRef = FirebaseDatabase.getInstance().getReference().child("users");
        firebaseAuth = FirebaseAuth.getInstance();

        // EditText 초기화
        nameEditText = findViewById(R.id.nameEditText);
        nicknameEditText = findViewById(R.id.nicknameEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        // Button 초기화
        editButton = findViewById(R.id.EditButton);
        backButton = findViewById(R.id.backButton);

        // 현재 로그인한 사용자 가져오기
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        // 현재 사용자의 정보 가져와서 EditText에 표시
        if (currentUser != null) {
            emailEditText.setText(currentUser.getEmail());
        }

        // 수정 버튼 클릭 시 이벤트 처리
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editUserInfo();
            }
        });

        // 뒤로 가기 버튼 클릭 시 이벤트 처리
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    // 사용자 정보 수정 메서드
    private void editUserInfo() {
        String name = nameEditText.getText().toString().trim();
        String nickname = nicknameEditText.getText().toString().trim();
        String birthdate = birthdateEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // 현재 로그인한 사용자 가져오기
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        if (currentUser != null) {
            // Firebase에 업데이트할 사용자 정보 설정
            User user = new User(name, nickname, birthdate, phone, currentUser.getEmail(), password);

            // Firebase 데이터베이스에 사용자 정보 업데이트
            usersRef.child(currentUser.getUid()).setValue(user)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MyEditActivity.this, "사용자 정보가 성공적으로 업데이트되었습니다.", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(MyEditActivity.this, "사용자 정보 업데이트에 실패했습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        } else {
            // 사용자가 로그인되어 있지 않음
            Toast.makeText(MyEditActivity.this, "사용자 정보를 업데이트할 수 없습니다. 로그인 상태를 확인하세요.", Toast.LENGTH_SHORT).show();
        }
    }
}

class User {
    private String name;
    private String nickname;
    private String birthdate;
    private String phone;
    private String email;
    private String password;

    public User() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(String name, String nickname, String birthdate, String phone, String email, String password) {
        this.name = name;
        this.nickname = nickname;
        this.birthdate = birthdate;
        this.phone = phone;
        this.email = email;
        this.password = password;
    }

    // Getter and setter methods...
}
