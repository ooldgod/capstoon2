package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import android.content.Intent;

public class DetailedInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_info);

        // 아직 자세한 정보가 없는 페이지 표시
        TextView textView = findViewById(R.id.textView);
        textView.setText("준비 중인 페이지입니다.");
    }
    public void onBackButtonClick(View view) {
        // MainActivity로 이동
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish(); // 현재 액티비티 종료
    }
}