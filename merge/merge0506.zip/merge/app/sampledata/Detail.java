package com.example.myapplication;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import android.graphics.Color;


import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.squareup.picasso.Picasso;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class Detail extends AppCompatActivity implements OnMapReadyCallback {
    private LineChart lineChart;
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);

        Button back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // MainItem으로 이동하면서 플래그 전달
                Intent intent = new Intent(getApplicationContext(), MainItem.class);
                intent.putExtra("go_to_menu_product", true); // 플래그 추가
                startActivity(intent);
                finish(); // 현재 액티비티 종료
            }
        });

        // 컴포넌트 참조
        TextView titleTextView = findViewById(R.id.title_text_view);
        ImageView productImageView = findViewById(R.id.product_image_view);
        TextView productInfoTextView = findViewById(R.id.product_info_text_view);
        TextView priceTextView = findViewById(R.id.price_text_view);
        TextView discountTextView = findViewById(R.id.discount_text_view);
        TextView storeTextView = findViewById(R.id.storeTextView);



        // 컴포넌트 속성 설정
        titleTextView.setText("상품 상세");

        String name = getIntent().getStringExtra("drink_name");
        String img_url = getIntent().getStringExtra("drink_img");
        int price = getIntent().getIntExtra("drink_Price",0);
        String event = getIntent().getStringExtra("drink_event");
        String store = getIntent().getStringExtra("drink_store");

        String price2 = Integer.toString(price);

        Picasso.get()
                .load(img_url) // 이미지 URL
                .into(productImageView);
        productInfoTextView.setText(name);
        discountTextView.setText(event);
        priceTextView.setText(price2+"원");
        storeTextView.setText(store);

        /*
        // Firestore 인스턴스 가져오기
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        for (int i = 1; i < 2; i++) {
            // Firestore 컬렉션 참조 가져오기
            CollectionReference productsRef = db.collection("products");

            String collectionPath = "2024_"+i+편의점상품";

            // name과 일치하는 상품명의 가격 가져오기
            productsRef.whereEqualTo("name", name)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    // 상품 가격 가져오기
                                    int price = document.getLong("price").intValue(); // 가격 필드가 Long 형일 경우
                                    // 리스트에 추가 또는 가격 설정
                                    // 이후의 작업을 진행합니다.
                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });

        }

         */



        ArrayList<Entry> entry_chart1 = new ArrayList<>(); // 데이터를 담을 Arraylist

        lineChart = (LineChart) findViewById(R.id.chart);
        lineChart.setGridBackgroundColor(Color.TRANSPARENT);
        lineChart.setDrawGridBackground(false); // 격자무늬 그리기 비활성화
        lineChart.setBackgroundColor(Color.TRANSPARENT); // 배경색을 투명하게 설정

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        xAxis.setDrawGridLines(false);

        YAxis yAxisLeft = lineChart.getAxisLeft();
        yAxisLeft.setDrawGridLines(false);

        YAxis yAxisRight = lineChart.getAxisRight();
        yAxisRight.setDrawLabels(false);
        yAxisRight.setDrawAxisLine(false);
        yAxisRight.setDrawGridLines(false);


        LineData chartData = new LineData(); // 차트에 담길 데이터

        entry_chart1.add(new Entry(1, 1)); //entry_chart1에 좌표 데이터를 담는다.
        entry_chart1.add(new Entry(2, 2));
        entry_chart1.add(new Entry(3, 3));
        entry_chart1.add(new Entry(4, 4));
        entry_chart1.add(new Entry(5, 2));

        LineDataSet lineDataSet1 = new LineDataSet(entry_chart1, "LineGraph1"); // 데이터가 담긴 Arraylist 를 LineDataSet 으로 변환한다.


        lineDataSet1.setColor(Color.RED); // 해당 LineDataSet의 색 설정 :: 각 Line 과 관련된 세팅은 여기서 설정한다.


        chartData.addDataSet(lineDataSet1); // 해당 LineDataSet 을 적용될 차트에 들어갈 DataSet 에 넣는다.


        lineChart.setData(chartData); // 차트에 위의 DataSet을 넣는다.



        lineChart.invalidate(); // 차트 업데이트
        lineChart.setTouchEnabled(false); // 차트 터치 disable

        //지도표시

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);










        ToggleButton favouriteToggle = findViewById(R.id.favourite);

        favouriteToggle.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        String toast;
                        if(isChecked) {
                            toast = "즐겨찾기에 추가되었습니다.";
                        }
                        else {
                            toast = "즐겨찾기에 해제되었습니다.";
                        }

                        Toast.makeText(Detail.this,toast,Toast.LENGTH_SHORT).show();
                    }
                }
        );


    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {

        mMap = googleMap;

        LatLng SEOUL = new LatLng(37.56, 126.97);

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(SEOUL);
        markerOptions.title("서울");
        markerOptions.snippet("한국의 수도");
        mMap.addMarker(markerOptions);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(SEOUL));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(11));
    }



}