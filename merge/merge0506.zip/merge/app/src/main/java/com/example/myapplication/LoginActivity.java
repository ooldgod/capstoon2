package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.FirebaseAuth;
import android.widget.TextView;
import android.view.View.OnClickListener;

public class LoginActivity extends Fragment {

    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private FirebaseAuth firebaseAuth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_login, container, false);

        // 파이어베이스 인증 객체 초기화
        firebaseAuth = FirebaseAuth.getInstance();

        // UI 컴포넌트와 변수 연결
        emailEditText = view.findViewById(R.id.emailEditText);
        passwordEditText = view.findViewById(R.id.passwordEditText);
        loginButton = view.findViewById(R.id.loginButton);

        TextView registerTextView = view.findViewById(R.id.register);
        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 클릭 이벤트 처리 코드
                goToSignUpActivity();
            }
        });

        // 로그인 버튼 클릭 리스너 설정
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        return view;
    }

    private void loginUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // 이메일과 비밀번호 유효성 검사
        if(email.isEmpty() || password.isEmpty()) {
            Toast.makeText(getContext(), "이메일 또는 비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
        } else {
            // 파이어베이스를 사용한 로그인 처리
            firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(requireActivity(), task -> {
                        if(task.isSuccessful()) {
                            // 로그인 성공 시 처리
                            Toast.makeText(getContext(), "로그인 성공!", Toast.LENGTH_SHORT).show();
                            // MyInfoActivity로 이동
                            startActivity(new Intent(requireContext(), MyInfoActivity.class));
                            requireActivity().finish(); // LoginActivity를 종료하여 뒤로가기 버튼을 눌렀을 때 다시 로그인 화면으로 돌아가지 않도록 함
                        } else {
                            // 로그인 실패 시 처리
                            Toast.makeText(getContext(), "로그인 실패: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void goToSignUpActivity() {
        Intent intent = new Intent(requireContext(), SignUpActivity.class);
        startActivity(intent);
    }
}
