package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class MainMenuHomeFragment extends Fragment {

    private ListView listView;
    private ArrayList<String> itemsList;
    private ArrayAdapter<String> adapter;
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;



    public MainMenuHomeFragment() {
        // Required empty public constructor
    }

    public static MainMenuHomeFragment newInstance(String param1, String param2) {
        MainMenuHomeFragment fragment = new MainMenuHomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.main_home, container, false);
        listView = rootView.findViewById(R.id.home_border_listView);
        itemsList = new ArrayList<>();
        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, itemsList);
        listView.setAdapter(adapter);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("2024_01편의점상품")
                .limit(10)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String productName = document.getString("product_name");
                            String mainCategory = document.getString("main_category");
                            String item = productName + "\n" + mainCategory;
                            itemsList.add(item);
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        // Firestore에서 데이터 가져오기 실패
                    }
                });



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedItem = itemsList.get(position);
                Activity activity = getActivity();
                Intent intent = new Intent(activity, Detail.class);
                /*intent.putExtra("drink_id", item.getId());
                intent.putExtra("drink_img",clickedItem.getImageUrl());
                intent.putExtra("drink_name",clickedItem.getName());
                intent.putExtra("drink_Price",clickedItem.getPrice());
                intent.putExtra("drink_event",clickedItem.getEvent());
                intent.putExtra("drink_store",clickedItem.getConvenienceStore());
                activity.startActivity(intent);*/

                intent.putExtra("clicked_item", clickedItem);
                assert activity != null;
                activity.startActivity(intent);
            }
        });

        return rootView;
    }




}