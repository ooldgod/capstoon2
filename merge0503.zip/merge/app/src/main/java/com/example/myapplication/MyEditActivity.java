package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import android.util.Log;

public class MyEditActivity extends AppCompatActivity {

    private EditText nameEditText, nicknameEditText, birthdateEditText, phoneEditText, emailEditText, passwordEditText;
    private Button editButton, backButton;

    // Firestore 및 인증 인스턴스 생성
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private static final String TAG = "MyEditActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_edit);

        // Firestore 및 인증 초기화
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // 레이아웃 요소 연결
        nameEditText = findViewById(R.id.nameEditText);
        nicknameEditText = findViewById(R.id.nicknameEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        editButton = findViewById(R.id.EditButton);
        backButton = findViewById(R.id.backButton);

        // 수정 버튼 클릭 이벤트 설정
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUserInformation();
            }
        });

        // 뒤로 가기 버튼 클릭 이벤트 설정
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // MyInfoActivity로 이동
                Intent intent = new Intent(MyEditActivity.this, MyInfoActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void updateUserInformation() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String newName = nameEditText.getText().toString().trim();
            String newNickname = nicknameEditText.getText().toString().trim();
            String newBirthdate = birthdateEditText.getText().toString().trim();
            String newPhone = phoneEditText.getText().toString().trim();

            // 현재 사용자의 이메일 가져오기
            String email = currentUser.getEmail();

            // Firestore에서 해당 사용자의 정보 업데이트
            DocumentReference userRef = db.collection("users").document(email);
            userRef.update("name", newName,
                            "nickname", newNickname,
                            "birthdate", newBirthdate,
                            "phone", newPhone)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(MyEditActivity.this, "정보가 성공적으로 업데이트되었습니다.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MyEditActivity.this, "정보를 업데이트하는 중 오류가 발생했습니다.", Toast.LENGTH_SHORT).show();
                            // 에러가 발생했을 때 로그에 더 자세한 정보 출력
                            Log.e(TAG, "Error updating user information", e);
                        }
                    });
        }
    }
}