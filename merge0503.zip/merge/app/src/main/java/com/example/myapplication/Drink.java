package com.example.myapplication;



public class Drink {
    private int id;
    private String name;
    private int price;
    private String convenienceStore;
    private boolean hasEvent;
    private String event;
    private String category;
    private String updateDate;
    private Integer likeCount; // 추천 카운터를 나타내는 Integer
    private Integer dislikeCount; // 비추천 카운터를 나타내는 Integer

    private String imageUrl;

    public Drink(String name, int price, String convenienceStore, boolean hasEvent, String event, String category, String updateDate, String imageUrl) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.convenienceStore = convenienceStore;
        this.hasEvent = hasEvent;
        this.event = event;
        this.category = category; // category 필드에 값 설정
        this.updateDate = updateDate;
        this.likeCount = 0; // 초기 값 설정
        this.dislikeCount = 0; // 초기 값 설정
        this.imageUrl = imageUrl;
    }

    // Getter 및 Setter 메서드 추가
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getPrice() {
        return price;
    }

    public String getConvenienceStore() {
        return convenienceStore;
    }

    public boolean hasEvent() {
        return hasEvent;
    }

    public String getEvent() {
        return event;
    }

    public String getCategory() {
        return category; // getCategory 메서드 추가
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public Integer getDislikeCount() {
        return dislikeCount;
    }

    public String getImageUrl() { // imageUrl 반환하는 getter 메서드
        return imageUrl;
    }

    public void like() {
        if (likeCount == null) {
            likeCount = 1;
        } else {
            likeCount++;
        }
    }

    public void dislike() {
        if (dislikeCount == null) {
            dislikeCount = 1;
        } else {
            dislikeCount++;
        }
    }

    public void cancelLike() {
        if (likeCount != null && likeCount > 0) {
            likeCount--;
        }
    }

    public void cancelDislike() {
        if (dislikeCount != null && dislikeCount > 0) {
            dislikeCount--;
        }
    }

}


