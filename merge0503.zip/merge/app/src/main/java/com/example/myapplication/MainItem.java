package com.example.myapplication;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import android.view.MenuItem;

public class MainItem extends AppCompatActivity {

    private MainMenuHomeFragment fragmentHome;
    private MainActivity fragmentProduct;
    private MainMenuHeart fragmentHeart;
    private LoginActivity fragmentMore;
    private MainMap fragmentMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_item);

        fragmentHome = MainMenuHomeFragment.newInstance("데이터를 전달할 내용", null);
        fragmentProduct = new MainActivity();
        fragmentHeart = new MainMenuHeart();
        fragmentMore = new LoginActivity();
        fragmentMap = new MainMap();


        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.menu_frame_layout, fragmentHome).commitAllowingStateLoss();

        BottomNavigationView bottomNavigationView = findViewById(R.id.menu_bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new ItemSelectedListener());
    }

    class ItemSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener {
        public boolean onNavigationItemSelected(MenuItem menuItem) {
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            int itemId = menuItem.getItemId();

            if (itemId == R.id.menu_home) {
                transaction.replace(R.id.menu_frame_layout, fragmentHome).commitAllowingStateLoss();
                return true;
            } else if (itemId == R.id.menu_product) {
                transaction.replace(R.id.menu_frame_layout, fragmentProduct).commitAllowingStateLoss();
                return true;
            }
            else if (itemId == R.id.menu_map){
                transaction.replace(R.id.menu_frame_layout, fragmentMap).commitAllowingStateLoss();
                return true;
            }
            else if (itemId == R.id.menu_heart) {
                transaction.replace(R.id.menu_frame_layout, fragmentHeart).commitAllowingStateLoss();
                return true;
            } else if (itemId == R.id.menu_more) {
                transaction.replace(R.id.menu_frame_layout, fragmentMore).commitAllowingStateLoss();
                return true;
            }
            return false;
        }
    }
}