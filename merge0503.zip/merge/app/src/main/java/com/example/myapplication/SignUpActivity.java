package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.CollectionReference;
import androidx.annotation.NonNull;
import com.google.firebase.auth.AuthResult;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;


public class SignUpActivity extends AppCompatActivity {

    private EditText nameEditText, nicknameEditText, birthdateEditText, phoneEditText, emailEditText, passwordEditText;
    private Button signUpButton, backButton;
    private FirebaseAuth mAuth;
    private FirebaseFirestore firestore = FirebaseFirestore.getInstance();
    private CollectionReference usersCollectionRef = firestore.collection("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        mAuth = FirebaseAuth.getInstance();

        // Initialize EditTexts
        nameEditText = findViewById(R.id.nameEditText);
        nicknameEditText = findViewById(R.id.nicknameEditText);
        birthdateEditText = findViewById(R.id.birthdateEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        signUpButton = findViewById(R.id.signUpButton);
        backButton = findViewById(R.id.backButton);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Firebase Authentication에 사용자 추가
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // 사용자가 성공적으로 Firebase Authentication에 추가되었을 때
                                    registerUser(); // Firestore에 사용자 정보 저장
                                } else {
                                    // 사용자 추가 실패 시
                                    Toast.makeText(SignUpActivity.this, "회원가입 실패: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                finish();
            }
        });
    }

    private void registerUser() {
        String name = nameEditText.getText().toString().trim();
        String nickname = nicknameEditText.getText().toString().trim();
        String birthdate = birthdateEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Simple validation
        if (!name.isEmpty() && !nickname.isEmpty() && !birthdate.isEmpty() && !phone.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
            // Firestore에 사용자 정보 저장
            User user = new User(name, nickname, birthdate, phone, email, password);
            usersCollectionRef.add(user)
                    .addOnSuccessListener(documentReference -> {
                        // Firestore에 사용자 정보 저장 성공
                        Toast.makeText(SignUpActivity.this, "회원가입 및 Firestore에 정보 저장 성공", Toast.LENGTH_SHORT).show();
                        // 회원가입 성공 후 LoginActivity로 이동
                        startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        // Firestore에 사용자 정보 저장 실패
                        Toast.makeText(SignUpActivity.this, "회원가입 실패: Firestore에 정보 저장 실패", Toast.LENGTH_SHORT).show();
                    });
        } else {
            // 필수 입력 필드가 비어 있을 때의 처리
            Toast.makeText(SignUpActivity.this, "모든 필드를 입력하세요", Toast.LENGTH_SHORT).show();
        }
    }

    public class User {
        public String name, nickname, birthdate, phone, email, password;

        // Default constructor는 Firestore에서 사용되지 않으므로 삭제합니다.

        // Modified constructor to include email
        public User(String name, String nickname, String birthdate, String phone, String email, String password) {
            this.name = name;
            this.nickname = nickname;
            this.birthdate = birthdate;
            this.phone = phone;
            this.email = email;
            this.password = password;
        }
    }
}
