package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainMenuHomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private ImageAdapter adapter;
    private List<Integer> imageList;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public MainMenuHomeFragment() {
        // Required empty public constructor
    }

    public static MainMenuHomeFragment newInstance(String param1, String param2) {
        MainMenuHomeFragment fragment = new MainMenuHomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        addNewImage(); // 화면을 켤 때 랜덤 이미지 추가
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.main_news, container, false);

        // RecyclerView 설정
        recyclerView = view.findViewById(R.id.noticeRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        imageList = new ArrayList<>();
        adapter = new ImageAdapter(imageList);
        recyclerView.setAdapter(adapter);

        // "더보기" TextView 클릭 리스너 설정
        TextView tvSeeMore = view.findViewById(R.id.tvSeeMoreNotices);
        tvSeeMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewImage(); // 새로운 이미지 추가
            }
        });

        return view;
    }

    private void addNewImage() {
        // 새로운 이미지를 가져오기
        int newImageResource = getRandomImageResource();

        // 이미 나온 이미지인지 확인
        while (imageList.contains(newImageResource)) {
            newImageResource = getRandomImageResource();
        }

        // 새로운 이미지를 이미지 목록에 추가
        imageList.add(newImageResource);

        // 어댑터에 데이터 변경 알림
        adapter.notifyDataSetChanged();
    }

    private int getRandomImageResource() {
        // 임의의 이미지 리소스 ID를 반환하는 메소드
        // 'ex'로 시작하는 이미지만 선택하여 반환
        String packageName = requireContext().getPackageName();
        Random random = new Random();
        int resourceId;
        do {
            int randomIndex = random.nextInt(10); // 이미지 개수에 맞게 수정
            String resourceName = "ex" + (randomIndex + 1);
            resourceId = getResources().getIdentifier(resourceName, "drawable", packageName);
        } while (resourceId == 0 || imageList.contains(resourceId)); // 이미지가 없거나 중복되면 다시 선택

        return resourceId;
    }
    // RecyclerView 어댑터 클래스
    private static class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {
        private List<Integer> imageList;

        public ImageAdapter(List<Integer> imageList) {
            this.imageList = imageList;
        }

        @NonNull
        @Override
        public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_image, parent, false);
            return new ImageViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
            int imageResource = imageList.get(position);
            holder.imageView.setImageResource(imageResource);
        }

        @Override
        public int getItemCount() {
            return imageList.size();
        }

        // ViewHolder 클래스
        public static class ImageViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;

            public ImageViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.imageView);
            }
        }
    }
}